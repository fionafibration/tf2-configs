![Logo](https://i.imgur.com/B6g5fCV.png)

**A very BRIGHT Team Fortress 2 Hud by Hypnotize**

<a>LINKS</a>
====

[LIGHT THEME Screenshots](https://imgur.com/a/4BZs0ih)

[DARK THEME Screenshots](https://imgur.com/a/Z8KJa9B)

[Huds.tf](https://huds.tf/forum/showthread.php?tid=1754)

[TeamFortress.TV](https://www.teamfortress.tv/53596/sunset-hud)

[HUD Wiki](https://github.com/Hypnootize/Sunset-Hud/wiki)

[HUD Installation](https://github.com/Hypnootize/Sunset-Hud/wiki/Installation)

[HUD Customization](https://github.com/Hypnootize/Sunset-Hud/wiki/Customization)

[Credits](https://github.com/Hypnootize/Sunset-Hud/wiki/Credits)
