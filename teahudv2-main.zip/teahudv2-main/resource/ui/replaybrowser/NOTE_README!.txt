Taken from hl2/hl2_misc_dir.vpk/resource/ui/
this wont make it using the autoupdate script!!

