if you wish to activate the customizations, just drag and drop
the files into the "Enabled" folder before editing them, every 
customization needs a "hud_reloadscheme" in console to work.

-DrinkinTea.