#!/bin/sh

# always add / create class cfg's in cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/scout.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/soldier.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/pyro.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/demoman.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/heavyweapons.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/engineer.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/medic.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/sniper.cfg
cat dev/ref/add_to_class.cfg >> ../../cfg/spy.cfg
